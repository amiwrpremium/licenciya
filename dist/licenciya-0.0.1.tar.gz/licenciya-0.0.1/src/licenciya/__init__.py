from src.licenciya.main import Licenciya
from src.licenciya import exceptions

__version__ = "0.0.1"
__author__ = 'amiwrpremium'
