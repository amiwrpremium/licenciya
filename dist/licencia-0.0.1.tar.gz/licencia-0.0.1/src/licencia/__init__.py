from src.licencia.main import Licencia
from src.licencia import exceptions

__version__ = "0.0.1"
__author__ = 'amiwrpremium'
